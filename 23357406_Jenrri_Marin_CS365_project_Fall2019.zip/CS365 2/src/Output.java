import java.util.Vector;

public final class Output
{
    public double FV;     // fair value
    public double fugit;  // fugit
    public double impvol; // implied volatility
    public int num_iter;  // number of iterations to compute implied volatility

    /**
     * The values of the Output class members are set in the library functions and returned to the calling application.
     *
     * 1.) Note that all output fields may be populated by a given function.
     * 2.) For example the function binom populates the values of FV and fugit, but not impvol and num_iter.
     */

    void printTree(Vector<Vector<Double>> tree)
    {
        tree.forEach((n) -> System.out.println(n));
    }

    public double getFV() {
        return FV;
    }
    public void setFV(double fV) {
        FV = fV;
    }
    public double getFugit() {
        return fugit;
    }
    public void setFugit(double fugit) {
        this.fugit = fugit;
    }
    public double getImpvol() {
        return impvol;
    }
    public void setImpvol(double impvol) {
        this.impvol = impvol;
    }
    public int getNum_iter() {
        return num_iter;
    }
    public void setNum_iter(int num_iter) {
        this.num_iter = num_iter;
    }

}
