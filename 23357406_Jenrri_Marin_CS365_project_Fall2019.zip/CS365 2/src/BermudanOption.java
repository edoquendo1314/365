

/**
 * The class BermudanOption is a non-abstract class which is an American-style vanilla option,
 * but it allows early exercise only in the time window w_begin <= t <= w_end
 *
 * A real Bermudan option can have many time windows, but we shall support
 * only one time window.
 *
 * The BerudanOption class must contain suitable indicative data members
 * and override the virtual functions in Derivative.
 *
 */
public class BermudanOption extends Derivative
{
    public double window_begin;
    public double window_end;

    @Override
    public void terminalCondition(Node n)
    {

    }

    @Override
    public void valuationTest(Node n)
    {

    }

}
