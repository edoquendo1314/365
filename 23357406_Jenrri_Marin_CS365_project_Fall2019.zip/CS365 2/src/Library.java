import java.util.Vector;

public final class Library
{
    //implements the binomial model to compute the fair value
    //and fugit of a derivative
    /**
     * 1.)The values of the fair value and fugit are returned in
     * an Output object
     *
     * 2.) The binom function
     * should perform validation checks to test for bad inputs.
     *
     * 3.) If the inputs are invalid then the function
     *  should set the fair value and fugit to zero
     */
    public Output binom(final Derivative deriv, final MarketData mkt, int n)
    {
        double qDiv = 0.1;
        double deltaT = (deriv.getT() - mkt.getT0())/ n;
        double discountFactor = Math.exp((-mkt.getR()*deltaT));
        double growthFactor = Math.exp((mkt.getR()-qDiv)*deltaT);
        double u = Math.exp(mkt.getSigma()* Math.sqrt(deltaT));
        double d = 1/u;
        double p = (growthFactor - d)/ (u-d);
        double q = (u - growthFactor) / (u - d);
        Vector<Vector<Node>> tree = new  Vector<Vector<Node>> ();
        for (int i = 1;i<= n+1; i++){
            Vector<Node> S = new Vector<Node>(i);

            for(int j = 0; j < i; ++j){
            double result = ((mkt.getS() * Math.pow(u,j)) * (Math.pow(d,i-j-1)));
            if(result == 99.99999999999999)
                {
                    result = 100.0;
                }
            Node obj = new Node();
            obj.setK(mkt.getPrice());
            obj.setBaseVal(result);
            deriv.terminalCondition(obj);
            S.add(j, obj);
            }
           tree.add(S);
        }

      for (int i = tree.size()-2;i>=0;i--){
          for (int j = tree.get(i).size()-1; j >=0; --j){
double holder = (growthFactor * ( (p*tree.get(i+1).get(j+1).getFv1()) + (q*tree.get(i+1).get(j).getFv1())));
double actual = Math.max(holder,tree.get(i).get(j).getFv1());
            // tree.elementAt(i).elementAt(j).setFinalFV((growthFactor * ( (p*tree.get(i+1).get(j+1).getFv1()) + (q*tree.get(i+1).get(j).getFv1()))));
tree.get(i).get(j).setFinalFV(actual);
            //  deriv.valuationTest(tree.elementAt(i).elementAt(j));

          }
      }
//        for (int i = 0;i<= tree.size()-1;i++){
//
//            for (int j = 0; j <= tree.get(i).size()-1; j++){
//
//                System.out.println(tree.get(i).get(j).getFinalFV());
//            }
//        }


      //System.out.println(tree.get(0).get(0).getFinalFV());
        Node binomialTree = new Node();

        Output test = new Output();
        test.setFV(tree.get(0).get(0).getK());
        return test;

    }

    //executes a loop of iterations to calculate the
    //implied volatility of a derivative
    /**
     * The library function impvol calculates the implied volatility
     * of an input derivative
     *
     * The market price of the derivative is supplied in the MarketData object
     *
     * To calculate the implied volatility, the function impvol calls binom in a loop
     *
     * The number of loop iterations and the implied volatility are returned in the OUTPUT object
     *
     * The function must not change the input data,
     * hence they are tagged as final objects
     */
//    public int impvol(final Derivative deriv, final MarketData mkt, int n, int max_iter, double tol, Output out)
//    {
//        max_iter = 100; //max_iter specifies the maximum num of iterations to execute in the loop
//        //The value of tol specifies the tolerance in the iteration
//        //Iterate until the following condition is satisfied
//        // |(Fair value) - mkt.Price| <= tol
//        //To test code you may set tol =1.0 e-4
//        tol = 1.0e-4;
//
//
//    }

}
