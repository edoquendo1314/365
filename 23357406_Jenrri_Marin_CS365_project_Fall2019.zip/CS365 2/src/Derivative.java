
/**
 * The class Derivative is an abstract base class which supports virtual functions for use in the valuation of derivatives
 *
 * All the derivatives we shall treat in this course have an expiration time T.
 *
 * Hence the Derivative class contains a data member double T.
 *
 * The virtual functions must be overridden by non-abstract derived classes.
 * 1.) The virtual function TERMINALCONDITION sets the PAYOFF VALUE and the FUGIT VALUE on the expiration date.
 *
 * 2.) The virtual function VALUATIONTEST is called when traversing the tree in the binomial model,
 *  to make decisions about early exercise and to set the FAIR VALUE and FUGIT to appropriate values
 *
 * 3.) The NODE object must therefore contain suitable data members and methods for the above functions to perform their tasks.
 */

public abstract class Derivative
{


    public double T;
    public double getT() {
        return T;
    }// data member

    abstract void terminalCondition(Node n); // virtual function


    abstract void valuationTest(Node n);    // virtual function


    public void setT(double t) {
       this.T = t;
    }

    public static double erf(double z) {
        double t = 1.0 / (1.0 + 0.5 * Math.abs(z));

        // use Horner's method
        double ans = 1 - t * Math.exp(-z * z - 1.26551223 +
                t * (1.00002368 +
                        t * (0.37409196 +
                                t * (0.09678418 +
                                        t * (-0.18628806 +
                                                t * (0.27886807 +
                                                        t * (-1.13520398 +
                                                                t * (1.48851587 +
                                                                        t * (-0.82215223 +
                                                                                t * (0.17087277))))))))));
        if (z >= 0) return ans;
        else return -ans;
    }
}