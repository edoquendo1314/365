public class Main {

    public static void main(String[] args)
    {
        // binom will do the tree building and the calculations as it traverses the tree.
    	MarketData mkt = new MarketData();
    	mkt.setPrice(100);
    	mkt.setR(0.1);
    	mkt.setS(100);
    	mkt.setSigma(0.5);
    	mkt.setT0(0.0);
        int n = 4;
        Derivative deriv = new VanillaOption();

        deriv.setT(0.4);
     //deriv.setT(0.0);
    Library x = new Library();
    x.binom(deriv,mkt,n);

        int S = 100; // Stock price
        int K = 100; // idk what this is but yh
        double r = 0.1; // risk free interest rate constant
        double qDiv = 0.1; //derivative that we have to get from derivative which is why its passed to binom
        double sigma = 0.5; // sigma value constant and volatility of the stock
        double T = 0.4;
        double t0 = 0.0;
        // n is what we pass to binom as well since it will denote the steps needed to perfrom the calls
        // relevant parameter calculations
        // this is important for building the tree see lecture 17  on how its suppose to be created.

        double deltaT = (T - t0)/ n;
        double discountFactor = Math.exp((-r* deltaT));
        double growthFactor = Math.exp((r-qDiv) * deltaT);
        double u = Math.exp(sigma* Math.sqrt(deltaT));
        double d = 1/u;
        double p = (growthFactor- d)/ (u - d);
        double q =  (u - growthFactor) / ( u - d); // continuos dividends at rate q for the stock
        //deriv.setT(0.0);
   //Node testTree = new Node();

      // Vector<Vector<Double>> trees = testTree.binomial_tree(S, u, d, n);

       // double interinsicValue = 0.0;
       // double fairValue = Math.exp((-r)*deltaT)*((p*85.375)+(q*188.117));
      //  System.out.println(fairValue);

    }

}
