
public class MarketData {
    public double Price; // market price of security
    public double S;     // stock price
    public double r; 	 // interest rate
    public double sigma; // volatility
    public double t0;    // current time

    /*
     * The values of the MarketData class members are set in a calling application
     * (for example the main() program),and the MarketData object is passed as an input to the above library functions
     *
     * It is your responsibility to write any class methods, etc. that you consider appropriate.
     *
     * GETTERS/SETTERS
     * Constructors that handle specific fields
     */
    public double getPrice() {
        return Price;
    }
    public void setPrice(double price) {
        Price = price;
    }
    public double getS() {
        return S;
    }
    public void setS(double s) {
        S = s;
    }
    public double getR() {
        return r;
    }
    public void setR(double r) {
        this.r = r;
    }
    public double getSigma() {
        return sigma;
    }
    public void setSigma(double sigma) {
        this.sigma = sigma;
    }
    public double getT0() {
        return t0;
    }
    public void setT0(double t0) {
        this.t0 = t0;
    }

}
