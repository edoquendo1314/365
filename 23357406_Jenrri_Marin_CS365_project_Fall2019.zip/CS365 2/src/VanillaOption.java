

/**
 * The class VanillaOption is a non-abstract class which extends Derivative,
 * to support the valuation of ordinary (vanilla) options.
 *
 * It must support put and call options, also American and European exercise
 * policies
 *
 * Therefore the VanillaOption must contain suitable indicative data members(primary key)
 *
 * The VanillaOption class must also override the virtual functions.
 *
 */
public  class VanillaOption extends Derivative
{


   @Override
    public void valuationTest(Node n)        // override
    {
    n.setFinalFV(Math.max(n.getFv1(),n.getFinalFV()));
    }

    @Override
    public void terminalCondition(Node n) {
      n.setFv1(Math.max(n.getBaseVal()-n.getK(),0));

    }
}
