/**
 * To Calculate the FAIR VALUE and FUGIT of a derivative, the binomial model should allocate NODE objects
 *
 * It is your responsibility to decide what data members and methods the Node class should contain.
 * It is your responsibility to decide how the BINOMIAL MODEL allocates the NODE objects, e.g. ARRAY || ARRAYLIST || HASHSET, etc.
 *
 */
//USING TREESET
public final class Node
{

    double baseVal;
    double Fv1;
    double finalFV;
    double fugit;
    double K;
    public double getK() {
        return K;
    }

    public void setK(double k) {
        K = k;
    }



    public double getFugit() {
        return fugit;
    }

    public void setFugit(double fugit) {
        this.fugit = fugit;
    }


    public double getBaseVal() {
        return this.baseVal;
    }

    public void setBaseVal(double baseVal) {
        this.baseVal = baseVal;
    }

    public double getFinalFV() {
        return finalFV;
    }

    public void setFinalFV(double finalFV) {
        this.finalFV = finalFV;
    }

    public double getFv1() {
        return this.Fv1;
    }

    public void setFv1(double fv1) {
        Fv1 = fv1;
    }


//    Vector<Vector<Double>>  binomial_tree(final double S_0, final double u, final double d, final int timeSteps)
//    {
//        double r = 0.1;
//        double T = 0.4;
//        double t0 = 0.0;
//        double qDiv = 0.1;
//        double sigma = 0.5;
//        double deltaT = (T - t0)/ 4;
//        double discountFactor = Math.exp((-r* deltaT));
//        double growthFactor = Math.exp((r-qDiv) * deltaT);
//        double p = (growthFactor- d)/ (u - d);
//        double q =  (u - growthFactor) / ( u - d);
//
//        Output print = new Output();
//        Vector<Vector<Double>> tree = new Vector<Vector<Double>>();
//        Vector<Vector<Double>> fairValueTree = new Vector<Vector<Double>>();
//        for(int i = 1; i <= timeSteps+1; ++i)
//        {
//            Vector<Double> xHolder = new Vector<Double>(i);
//            Vector<Double> S = new Vector<Double>(i);
//            for(int j = 0; j < i; ++j)
//            {
//                double result  = ((S_0 * Math.pow(u,j)) * (Math.pow(d,i-j-1)));
//                if(result == 99.99999999999999)
//                {
//                    result = 100.0;
//                }
//                xHolder.add(j,Math.max(result-100,0));
//                S.add(j,result);
//            }
//            fairValueTree.add(xHolder);
//            tree.add(S);
//        }
//        print.printTree(fairValueTree);
//        print.printTree(tree);
//        //reverse iteration
//        //sets the fair value for american call/put
//for (int i = fairValueTree.size()-2; i>=0;i--){
//    for (int j = fairValueTree.get(i).size()-1;j>=0;--j){
//        double holder = (growthFactor * ( (p*fairValueTree.get(i+1).get(j+1))+(q*fairValueTree.get(i+1).get(j))));
//        double actualValue = Math.max(holder, fairValueTree.get(i).get(j));
//        fairValueTree.get(i).set(j,actualValue);
//
//
//    }
//
//}
//print.printTree(fairValueTree);
//        return tree;
//    }

}
